# UI-kit agnostic simulator — usage and migration

**Package:** `@signalsafe/simulator-react`  
**Status:** Implemented (0.2.0+)  
**Related:** [UI_KIT_AGNOSTIC_REFACTOR.md](./UI_KIT_AGNOSTIC_REFACTOR.md) (design scan)

---

## Summary

`@signalsafe/simulator-react` ships **composable React session UI, screen registry, and utilities** with semantic HTML and stable **`simulator-*` class hooks**. It does **not** require Bootstrap, Material UI, or any other UI library.

**The host application owns styling.** Map `simulator-*` classes to your design system, or pass render slots to inject host UI components (Bootstrap `Button`, MUI, etc.).

Peer dependencies: `react`, `react-dom` only.

---

## Architecture

| Layer | Package | UI library |
|-------|---------|------------|
| Runtime stepping | `@signalsafe/simulator-core` | None |
| Wire | `@signalsafe/tree-spec` | None |
| Session + screens | `@signalsafe/simulator-react` | **Host-owned** — semantic hooks and optional slots |

---

## Class hooks (`simulator-*`)

Shell, lists, buttons, alerts, and modals emit predictable class names from `src/ui/simulatorClasses.ts` and `src/simulatorStyles.ts`:

| Token | Example classes | Used for |
|-------|-----------------|----------|
| Card chrome | `simulator-card`, `simulator-card__header`, `simulator-card__body` | Dev reports, timeline |
| Lists | `simulator-list`, `simulator-list__item`, `simulator-list__item--action` | Contacts, inbox, history |
| Buttons | `simulator-btn`, `simulator-btn--primary`, `simulator-btn--neutral-outline` | Choices, actions, nav |
| Alerts | `simulator-alert`, `simulator-alert--warning` | Lint banner, inline feedback |
| Modals | `simulator-modal`, `simulator-modal__dialog`, `simulator-modal__body` | Contacts verification overlay |
| Forms | `simulator-input`, `simulator-field`, `simulator-field__label` | Search, compose, login forms |
| Layout | `simulator-flex`, `simulator-flex--column`, `simulator-muted`, `simulator-shell__*` | Screen chrome, device shell |

**Tone mapping:** `SimulatorButton` and `renderSimulatorChoice` accept `SimulatorButtonTone` values (`primary`, `neutral-outline`, `link`, …). These map directly to `simulator-btn--*` hooks via `simBtnToneClass()`; Bootstrap aliases are removed.

---

## Semantic view hooks (stable DOM contract)

In addition to layout primitives (`simulator-btn`, `simulator-list`, …), major simulator views emit **stable semantic class names** from `src/ui/semanticSimulatorClasses.ts`. Host apps can target these in CSS or tests without `MutationObserver` DOM enhancers.

| Class | Region |
|-------|--------|
| `simulator-runtime` | Root wrapper around `SimulatorWithSession` |
| `simulator-runtime__screen` | Active screen content inside the device shell |
| `simulator-channel` | Channel wrapper (always present on screen) |
| `simulator-channel--phone` | Phone channel active |
| `simulator-channel--email` | Email channel active |
| `simulator-channel--messages` | Messages channel active |
| `simulator-phone` | Phone app view root |
| `simulator-phone__dialer` | Dial pad screen |
| `simulator-phone__dialer-call-button` | Green CALL button |
| `simulator-phone__incoming-call-history` | Call history list (includes incoming-call card) |
| `simulator-phone__incoming-call-extra` | Host slot region below incoming-call scene |
| `simulator-phone__incoming-call-after-actions` | Host slot inner wrapper below Answer/Ignore |
| `simulator-phone__contact-list` | Contact list container |
| `simulator-phone__contact-row` | Contact list row |
| `simulator-phone__contact-detail` | Contact detail panel |
| `simulator-email` | Email app view root |
| `simulator-email__inbox` | Inbox / folder list view |
| `simulator-email__message-row` | Inbox message row button |
| `simulator-email__message-detail` | Message read/detail view |
| `simulator-email__status-badge` | Read / Unread badge on inbox rows |
| `simulator-messages` | Messages thread list view root |
| `simulator-messages__thread-list` | Thread list container |
| `simulator-messages__thread-row` | Thread list row button |
| `simulator-messages__thread-detail` | Single-thread conversation view |

Semantic classes are **appended** alongside existing `simulator-*` layout hooks; host `className` props on primitives are preserved.

---

## Primitives (internal building blocks)

Small presentational components live in `src/ui/primitives.tsx`. These are internal building blocks; hosts typically style via `simulator-*` CSS or render slots. Maintainers may import from source when composing custom screens:

| Primitive | Role |
|-----------|------|
| `SimulatorButton` | `<button>` with `tone` → `simulator-btn--*` |
| `SimulatorInput`, `SimulatorTextarea` | Form controls |
| `SimulatorField`, `SimulatorLabel` | Field layout |
| `SimulatorCard` / `Header` / `Body` | Panel chrome |
| `SimulatorAlert` | Inline warnings and feedback |
| `SimulatorList` / `Item` | Selectable list rows |
| `SimulatorDialog` | Native `<dialog>` overlay |
| `SimulatorCollapse` | Expand/collapse sections |

---

## Render slots

Pass slots on **`SimulatorWithSession`** to replace default button/alert/modal markup without forking screen logic:

### `SimulatorWithSession`

| Prop | Purpose |
|------|---------|
| `renderChoice(choice)` | Host-owned buttons for Answer, Send, page actions, attachments, etc. |
| `renderFeedback(feedback)` | Host-owned inline warnings and feedback panels |
| `renderContactsOverlay(props)` | Replace the default contacts verification `<dialog>` |
| `renderIncomingCallExtra(props)` | Host-owned content below incoming-call Answer/Ignore (e.g. caller history) |
| `hostOwnsPhoneContactDetail` + `onPhoneContactOpen(props)` | Host-owned phone contact detail screen (list stays in package; detail UI is yours) |

### Slot prop types

```tsx
interface SimulatorChoiceRenderProps {
    label: ReactNode;
    onClick: () => void;
    tone?: string;
    className?: string;
    disabled?: boolean;
    'aria-label'?: string;
}

interface SimulatorFeedbackRenderProps {
    message: ReactNode;
    tone?: 'warning' | 'danger' | 'info';
    className?: string;
}

interface SimulatorContactsOverlayRenderProps {
    contacts: SimulatorSessionContact[] | null;
    verificationContext: { name?: string; number?: string } | null;
    onClose: () => void;
}

interface SimulatorPhoneIncomingCallExtraRenderProps {
    state: SimulatorSessionState;
    dispatch: (action: SimulatorDispatchAction) => void;
    content: PhoneSimulatorContent;
    callHistory: SimulatorCallHistoryEntry[];
    contacts: SimulatorSessionContact[] | null;
}

interface SimulatorPhoneContactOpenProps {
    state: SimulatorSessionState;
    dispatch: (action: SimulatorDispatchAction) => void;
    contactId: string;
    contact: SimulatorSessionContact;
}
```

`renderIncomingCallExtra` renders inside stable wrappers with classes `simulator-phone__incoming-call-extra` and `simulator-phone__incoming-call-after-actions`. Return `null` to omit the region (no empty wrappers). The slot is only invoked on the phone **incoming_call** screen.

When `hostOwnsPhoneContactDetail` is true, clicking a contact row on the phone **contacts** screen calls `onPhoneContactOpen` with the full contact record, session state, and dispatch. The package does **not** set internal selected-contact state or render `.simulator-phone__contact-detail`. Existing `open_contact` analytics still fire via the normal `onOpenContact` path. Omit the flag (or pass `false`) to keep the built-in contact detail view.

Example:

```tsx
<SimulatorWithSession
    state={state}
    dispatch={dispatch}
    hostOwnsPhoneContactDetail
    onPhoneContactOpen={({ contact, contactId, state, dispatch }) => {
        // Host renders its own edit/detail form using structured contact data
        setEditingContactId(contactId);
    }}
/>
```

Slots propagate through the screen registry into **SMS**, **browser**, and **phone** views. Internal helpers `renderSimulatorChoice` and `renderSimulatorFeedback` in `src/ui/renderSlots.tsx` delegate to the slot when provided.

---

## Hooks (session behavior)

Session stepping and screen dispatch remain in existing exports — no new required hook for basic embedding:

| Export | Role |
|--------|------|
| `simulatorSessionReducer` / `simulatorSessionReducerWithLogging` | Session state transitions |
| `getInitialSessionState` | Build initial view from payload |
| `renderActiveScreen` / `resolveScreen` | Screen registry (used internally by `SimulatorWithSession`) |

Internal hook `useSimulatorSessionHandlers` wires dispatch, events, and render context; hosts use `SimulatorWithSession` rather than importing it directly.

---

## Minimal host integration (plain HTML + CSS)

```tsx
import { useReducer } from 'react';
import SimulatorWithSession from '@signalsafe/simulator-react/SimulatorWithSession';
import PhoneSimulatorShell from '@signalsafe/simulator-react/shell/PhoneSimulatorShell';
import { getInitialSessionState } from '@signalsafe/simulator-react/state/simulatorSessionInitialState';
import { simulatorSessionReducer } from '@signalsafe/simulator-react/state/simulatorSessionReducer';
import { SimulatorTemplatePayload } from '@signalsafe/simulator-react/types/session';

// Host CSS — map simulator-* hooks (plain HTML styling, no UI library required)
import './simulator-host.css';

export function PlainSimulator({ payload }: { payload: SimulatorTemplatePayload }) {
    const [state, dispatch] = useReducer(simulatorSessionReducer, getInitialSessionState(payload));

    return (
        <PhoneSimulatorShell>
            <SimulatorWithSession state={state} dispatch={dispatch} />
        </PhoneSimulatorShell>
    );
}
```

Example host CSS (minimal):

```css
.simulator-btn { padding: 0.5rem 1rem; border: 1px solid #333; background: #fff; cursor: pointer; }
.simulator-btn--primary { background: #0d6efd; color: #fff; border-color: #0d6efd; }
.simulator-muted { color: #6c757d; font-size: 0.875rem; }
.simulator-modal::backdrop { background: rgba(0, 0, 0, 0.4); }
```

---

## Optional: Bootstrap in the host app (not a package requirement)

The snippets below are **host-app code**. `@signalsafe/simulator-react` does not depend on Bootstrap or `react-bootstrap`.

```tsx
import Button from 'react-bootstrap/Button';
import Alert from 'react-bootstrap/Alert';
import Modal from 'react-bootstrap/Modal';
import SimulatorWithSession from '@signalsafe/simulator-react/SimulatorWithSession';
import PhoneSimulatorShell from '@signalsafe/simulator-react/shell/PhoneSimulatorShell';
import { SimulatorChoiceRenderProps } from '@signalsafe/simulator-react/ui/renderSlots';
import { SimulatorFeedbackRenderProps } from '@signalsafe/simulator-react/ui/renderSlots';

// Host loads Bootstrap CSS — not required by the package
import 'bootstrap/dist/css/bootstrap.min.css';

function BootstrapSimulator(props: { state; dispatch }) {
    return (
        <PhoneSimulatorShell>
            <SimulatorWithSession
                {...props}
                renderChoice={({ label, onClick, tone, disabled, 'aria-label': ariaLabel }) => (
                    <Button variant={tone ?? 'primary'} onClick={onClick} disabled={disabled} aria-label={ariaLabel}>
                        {label}
                    </Button>
                )}
                renderFeedback={({ message, tone }) => (
                    <Alert variant={tone ?? 'warning'} className="small mb-0">
                        {message}
                    </Alert>
                )}
                renderContactsOverlay={({ contacts, verificationContext, onClose }) => (
                    <Modal show onHide={onClose} centered>
                        <Modal.Body>{/* host composes ContactsView or custom UI */}</Modal.Body>
                    </Modal>
                )}
            />
        </PhoneSimulatorShell>
    );
}
```

Alternatively, map `simulator-*` classes to Bootstrap utilities in host SCSS without render slots.

---

## DeliveryPlus migration (guidance only)

**Do not change DeliveryPlus in simulator package work.** When DeliveryPlus upgrades to `@signalsafe/simulator-react@0.2.0`:

1. **Remove** `react-bootstrap` as a peer dependency of this package — keep Bootstrap in DeliveryPlus if the app still uses it elsewhere.
2. **Choose a styling path:**
   - **CSS bridge:** map `simulator-*` → DeliveryPlus/Bootstrap theme, or
   - **Render slots:** pass `renderChoice`, `renderFeedback`, `renderContactsOverlay` with `react-bootstrap` components.
3. **Update tests** that assert `btn-*`, `list-group-*`, or `react-bootstrap` Modal markup — assert `simulator-*` or slot output instead.
4. **Short-term pin** — stay on `0.1.x` until host CSS or slots are ready; then bump to `0.2.0`.
5. **Future (optional)** — `@signalsafe/simulator-react-bootstrap` may provide a reference Bootstrap skin without coupling the core package.

Runtime markup emits **`simulator-*` hooks only** — map them in host CSS alongside panel/shell styling from `@signalsafe/tree-spec-editor` if used together.

---

## Semver

**0.2.0** — removes `react-bootstrap` peer dependency; changes default DOM/class contract to `simulator-*` hooks; adds optional render slots on `SimulatorWithSession`. Component export names are largely unchanged; visual parity requires host CSS or slot wiring.
