# Changelog

## 0.19.0-cleanup.4 (local, unpublished)

Remove legacy conversion, wire and presentation aliases; migrate consumers to canonical contracts. See MIGRATION.md.

## 0.18.0-ui.4 (local)

- Add an identity-content slot to PhoneContactEditor so hosts reuse its form and action controls with structured names and photo inputs.

## Unreleased — shared PhoneMe UI

- Use one shared call view, avatar/navigation primitives, and full-width history-row presentation across scenario and provider hosts.
- Move the default PhoneMe palette and screen layout into the theme package; preserve host data, callbacks, and explicit appearance configuration.
- Verify narrow devices and enlarged text, and prevent duplicate message actions when shell navigation renders them.
- Local `ui` prereleases are packed integration artifacts, not registry releases.

## 0.17.0 — September 29, 2026

- Export reusable Vault, Photos/editor/location, lock/settings, mutable Mailbox and HTML/React browser screens, page hooks and browser/file helpers.
- Add `SimulatorAppsProvider` for host formatting, notes editing, map rendering, file/metadata and lock adapters. Default notes use a plain textarea; external maps require an explicit host renderer.
- Add mailbox source slots and display adapters without importing host storage or import services.
- Add optional `photo`, `numberLabel` and `description` to `PhoneHistoryDetail`; media and number labels render inside the card body. Existing supplied descriptions still render.
- Require core 0.4.1; retain React 18 peers and add Lucide icons.

- Compile and execute the repository examples against the packed public API during package smoke checks.

## [Unreleased]

### Changed

- Require a matching GitHub version tag for npm publication; branch workflow runs only validate.

## [0.16.3] - 2026-09-16

### Changed

- Require simulator-core 0.3.2 and retain TreeSpec ^0.4.1.
- Include navigation quality fixes and additional runtime, payload, and host-interaction regression tests.

- Lower the runtime requirement to Node >=19.0.0 and refresh the TreeSpec lockfile to 0.4.1.
- Add isolated packed-consumer tests on Node 19.0.0 and Node 19–24; retain modern tooling checks on Node 22/24.

## 0.16.2 — 2026-09-16

- Refresh release tooling to Vitest 5; preserve React 18 compatibility.
- Add localized semantic page/list-group, contact-value and photo controls with default accessible SVG photo actions.
- Add controlled email/message/dial drafts, explicit action capabilities, selection-aware keypad editing and grouped contact fields.
- Preserve host navigation interception, screen overrides, readonly datasource snapshots and React 18 compatibility.
- Require simulator-core 0.3.1 and refresh TreeSpec dependencies; use standalone registry lockfiles.

## 0.4.0 — 2026-09-11

- Expose deeply readonly datasource snapshots, matching recursive runtime freezing. Nested writes now fail at compile time; use the existing mutable session conversion when editing content.
- Add `updateSimulatorPayload` to reconcile a previously converted payload without cloning content again.
- Compile negative public type checks alongside source checks and verify mutable-copy isolation.

## 0.3.0 — 2026-09-11

- Add validated JSON datasource snapshots sharing the existing full-device/session model.
- Add optional controlled call, keypad, contact editor, history detail/pagination and Home tile components.
- Include reviewed navigation contracts, screen overrides, accessible compose controls and semantic presentation/history hooks previously consumed by PhoneMe as local prereleases.
- Keep React 18 peers and provider-free scenario behavior; typecheck against declared packages without sibling source aliases.

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.11] - 2026-08-28

### Changed

- Require published `@signalsafe/simulator-core` **^0.1.10** and `@signalsafe/tree-spec` **^0.3.4**.

## [0.2.10] - 2026-08-28

### Changed

- Updated the TypeScript 7-compatible build configuration and current CI action dependencies.

### Notes

- No public React component API changes.

## [0.2.9] - 2026-07-02

### Changed

- Re-export canonical device payload types from `@signalsafe/simulator-core` in `portableSimulator.ts` instead of duplicating definitions in `@signalsafe/simulator-react`.
- Bumped `@signalsafe/simulator-core` dependency to `^0.1.8`.

### Added

- Tests asserting portable payload re-exports align with `@signalsafe/simulator-core` guards.

### Notes

- Additive compatibility release — existing `@signalsafe/simulator-react` import paths for payload types remain valid.
- Required by `@signalsafe/simulator-device@0.3.3` and DeliveryPlus registry pins.

## [0.2.4] - 2026-06-28

### Added

- Optional `hostOwnsPhoneContactDetail` and `onPhoneContactOpen` on `SimulatorWithSession` so hosts can render their own phone contact detail screen without DOM scraping.
- Exported `SimulatorPhoneContactOpenProps` type from the package barrel.
- Tests and docs for host-owned contact detail behavior.

### Notes

- Additive release only — default contact row behavior is unchanged when `hostOwnsPhoneContactDetail` is omitted or false.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.3] - 2026-06-30

### Added

- Optional `renderIncomingCallExtra` slot on `SimulatorWithSession` for host content below incoming-call Answer/Ignore actions.
- Semantic wrapper classes `simulator-phone__incoming-call-extra` and `simulator-phone__incoming-call-after-actions`.
- Exported `SimulatorPhoneIncomingCallExtraRenderProps` type from the package barrel.
- Tests and docs for the incoming-call extension point.

### Notes

- Additive release only — existing screens render unchanged when the slot is omitted.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.2] - 2026-06-29

### Added

- Stable semantic view class hooks (`simulator-runtime`, `simulator-phone`, `simulator-email`, `simulator-messages`, channel modifiers, dialer call button, contact rows, inbox rows, thread list/detail, etc.) for host CSS and tests without DOM enhancers.
- Tests asserting semantic classes render on key simulator views.
- README and `docs/UI_KIT_AGNOSTIC_USAGE.md` styling contract for semantic hooks.

### Notes

- Additive release only — no public React component API changes.
- No Bootstrap, Material, or ThemeProvider dependencies were added.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.1] - 2026-06-28

### Fixed

- Restored `@signalsafe/simulator-core` as a runtime dependency of `@signalsafe/simulator-react`.

### Notes

- No public React component API changes.
- No Bootstrap or UI framework dependencies were added.
- React and React DOM remain peer dependencies.

## [0.2.0] - 2026-06-28

### Changed

- Removed Bootstrap-specific runtime styling assumptions from the React simulator components.
- Replaced Bootstrap class coupling with UI-kit-agnostic `simulator-*` class hooks.
- Updated internal SignalSafe dependency ranges for the current package release line:
  - `@signalsafe/tree-spec@^0.3.3`
  - `@signalsafe/simulator-core@^0.1.7`
- Raised the supported Node.js baseline to Node 22.12+.

### Added

- Added learner-safe error rendering defaults.
- Added `showDiagnostics` support for author, admin, and QA surfaces.
- Added tests covering sanitized error output and unsupported-state rendering.
- Added package smoke checks for the built and packed artifact.

### Fixed

- Addressed SonarCloud findings in `src/ui/primitives.tsx`: mark component props as read-only, move clickable list-row handlers onto an inner `<button>` for keyboard accessibility, and use `export…from` for class-token re-exports.
- Added `simulator-list__item-button` class hook for host styling of clickable list rows.

### Notes

- This release does not include `react-bootstrap` or `bootstrap`.
- Host applications are responsible for styling the emitted `simulator-*` hooks.
- Learner-facing screens should keep diagnostics disabled by default.
- Diagnostics should only be enabled in trusted authoring, admin, development, or QA contexts.

## [0.1.6] - 2026-06-26

### Fixed

- Clear monorepo `paths` from standalone `tsconfig.build.json` so local `yarn build` works outside the monorepo.

### Changed

- Standardize development on Yarn 1.22.22 (`packageManager`, README dev commands).
- Bump `@signalsafe/simulator-core` to `^0.1.5` and `@signalsafe/tree-spec` to `^0.3.2`.

## [0.1.5] - 2026-06-26

### Added

- `SECURITY.md`, Dependabot, `CHANGELOG.md`, updated [RELEASING.md](./RELEASING.md).
- Expanded React package test coverage.
- Package artifact smoke test (`yarn smoke:package`).

### Changed

- Package metadata and README (Batches 3–4).

### CI

- Checks and tests on every PR; Sonar **`scan`** is label-gated on PRs and runs on tag push and manual dispatch (Batch 1).
- Publish only from manual **`main`** dispatch or **`v*`** tags (not PR labels); publish requires **`checks`**, **`tests`**, and **`scan`**.

[Unreleased]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.11...HEAD
[0.2.11]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.10...v0.2.11
[0.2.10]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.9...v0.2.10
[0.2.3]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.1.6...v0.2.0
[0.1.6]: https://github.com/SignalSafeSoftware/simulator-react/releases/tag/v0.1.6
[0.1.5]: https://github.com/SignalSafeSoftware/simulator-react/releases/tag/v0.1.5
